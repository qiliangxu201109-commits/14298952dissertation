# Independent MAP + Laplace approximate robustness validation

This is an approximate direction check, not the main PyMC/MCMC result.

## updated_wide

| Model | ELPD | SE | Brier | AUC | Exposure rank |
|---|---:|---:|---:|---:|---:|
| contacts | -30.918 | 1.819 | 0.2198 | 0.6621 | 1 |
| duration_minutes | -31.125 | 1.727 | 0.2216 | 0.6724 | 2 |
| pcm | -31.768 | 1.780 | 0.2278 | 0.6397 | 3 |
| participation | -33.126 | 1.657 | 0.2407 | 0.5741 | 4 |
| intercept_only | -34.107 | 1.271 | 0.2512 | 0.5000 | NA |

